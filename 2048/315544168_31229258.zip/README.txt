31544168
31229258	
*****
Comments:
Our heuristic consists of 2 functions: smoothness and steepness. 
Smoothness approximates the amount of merges that can be made from a
given board, and steepness approximates the monotonicity of the board,
giving the lower right corner the highest weight and decreasing 
gradually in direction of the upper left corner.
